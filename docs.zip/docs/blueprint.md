# **App Name**: PrivacySense

## Core Features:

- Secure Authentication & RBAC: Role-based authentication with Login Page only (no signup), supporting Admin, Manager, and Employee roles. Admin can create user accounts and manage credentials. Passwords are securely hashed using bcrypt, and JWT is used for session management with role-based authorization.
- Admin User & System Management: Admin dashboard provides full system access to create, manage, and update Manager and Employee accounts, manage user roles, and configure system settings. It integrates with Firestore to store user credentials and roles.
- Automated Personal Data Discovery Engine: Automatically scan enterprise data sources (databases, file servers, email systems, cloud storage) to detect personal identifiers (Names, Phone numbers, Email addresses, Aadhaar, PAN, Bank account numbers, Health information) using advanced pattern matching and natural language processing (NLP) tool. Results are stored in Firestore.
- Intelligent Data Classification System: Automatically classify discovered data into 'Highly Sensitive Data', 'Personal Data', and 'General Data' based on defined rules and contextual analysis, and tag files/records accordingly using an AI-powered tool. Classification results are stored in Firestore.
- Centralized Data Inventory Dashboard: A dashboard displaying a comprehensive data inventory with visual charts showing data type, storage location, department owner, sensitivity level, risk score, sensitive data distribution, department-wise exposure, and data storage locations. Data is retrieved from Firestore.
- Compliance Monitoring & Audit Logs: Track and log system activities, including user login activity, timestamp, device ID, MAC address, and location. Generate alerts for unauthorized access, suspicious activity, and potential data breaches, with logs stored in Firestore.
- Automated Compliance Report Generation: Generate on-demand automated compliance reports in PDF or Excel format for personal data inventory, data classification results, access logs, and risk analysis. Reports leverage data stored in Firestore.

## Style Guidelines:

- Color scheme: Dark theme for an authoritative and secure aesthetic. The background color is a very dark, desaturated purplish-blue (#21222C), providing depth and visual comfort for extended use.
- Primary color: A vibrant, yet refined indigo-blue (#677CE4) that stands out effectively against the dark background, used for primary interactive elements, important headings, and key information, conveying trust and innovation.
- Accent color: A soft, lighter lavender (#B7A6D9) provides a complementary visual element, used for secondary actions, subtle highlights, and to maintain visual hierarchy.
- Body and headline font: 'Inter' (sans-serif) will be used throughout the application. Its modern, objective, and highly legible design is ideal for presenting data-dense information, dashboards, and reports in an enterprise context.
- Utilize a consistent set of line-based or subtly filled icons that are professional, clear, and functional. Icons should directly convey concepts like data, security, compliance, and user roles, maintaining a serious tone appropriate for an enterprise application.
- The layout will be clean, structured, and modular, focusing on information hierarchy and readability. Dashboards will utilize a grid-based system with clear card/widget components for presenting data. Content areas will ensure efficient use of space without feeling cluttered.
- Subtle, professional animations will enhance the user experience without distraction. This includes smooth transitions for data updates, discreet loading indicators, and minimalist hover effects on interactive elements, ensuring a responsive and modern feel.