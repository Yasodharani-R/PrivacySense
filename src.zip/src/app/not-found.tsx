
"use client";

import { ShieldAlert, ArrowLeft, Home } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";

export default function NotFound() {
  const router = useRouter();

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background p-4 text-center">
      <div className="p-6 bg-destructive/10 rounded-3xl border border-destructive/20 mb-8 animate-pulse">
        <ShieldAlert className="h-20 w-20 text-destructive" />
      </div>
      
      <h1 className="text-6xl font-black tracking-tighter mb-2">404</h1>
      <h2 className="text-2xl font-bold mb-4">Route Restricted or Missing</h2>
      <p className="text-muted-foreground max-w-md mb-10 leading-relaxed">
        The requested system path could not be located or has been restricted due to enterprise security protocols.
      </p>

      <div className="flex gap-4">
        <Button variant="outline" className="gap-2 border-white/10" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4" />
          Go Back
        </Button>
        <Button className="gap-2" onClick={() => router.push("/")}>
          <Home className="h-4 w-4" />
          Return Home
        </Button>
      </div>

      <div className="mt-20 pt-8 border-t border-white/5 w-full max-w-xs">
        <p className="text-[10px] text-muted-foreground uppercase tracking-[0.3em] font-bold">
          PrivacySense Core Engine
        </p>
      </div>
    </div>
  );
}
