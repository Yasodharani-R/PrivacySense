
"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Shield, Lock, Mail, Info, Users, ShieldAlert, UserCheck, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth, useUser } from "@/firebase";
import { initiateEmailSignIn } from "@/firebase/non-blocking-login";
import { useToast } from "@/hooks/use-toast";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function LoginPage() {
  const router = useRouter();
  const { user, isUserLoading } = useUser();
  const auth = useAuth();
  const { toast } = useToast();
  
  const [email, setEmail] = useState("admin@privacysense.com");
  const [password, setPassword] = useState("password123");
  const [role, setRole] = useState("Admin");
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (user && !isUserLoading) {
      router.push("/dashboard");
    }
  }, [user, isUserLoading, router]);

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    initiateEmailSignIn(auth, email, password);
    
    toast({
      title: "Authenticating",
      description: `Connecting to ${role} terminal in enterprise directory...`,
    });

    setTimeout(() => setIsLoading(false), 3000);
  };

  const systemRoles = [
    { id: "Admin", name: "Admin", icon: ShieldAlert, desc: "System-wide control & user provisioning", color: "text-primary" },
    { id: "Manager", name: "Manager", icon: Users, desc: "Departmental discovery & compliance oversight", color: "text-secondary" },
    { id: "Employee", name: "Employee", icon: UserCheck, desc: "Personal data access & self-service logs", color: "text-emerald-500" },
  ];

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-primary/10 via-background to-background">
      <div className="w-full max-w-md space-y-6">
        <Card className="border-white/10 glass-panel shadow-2xl overflow-hidden">
          <CardHeader className="space-y-1 text-center pb-6 pt-8">
            <div className="flex justify-center mb-4">
              <div className="p-3 bg-primary/10 rounded-2xl border border-primary/20 shadow-inner">
                <Shield className="h-10 w-10 text-primary" />
              </div>
            </div>
            <CardTitle className="text-3xl font-bold tracking-tight gradient-text">PrivacySense</CardTitle>
            <CardDescription className="text-muted-foreground">
              Enterprise Data Discovery & Classification
            </CardDescription>
          </CardHeader>
          
          <form onSubmit={handleAuth}>
            <CardContent className="grid gap-5">
              <div className="grid gap-2">
                <label className="text-xs font-bold uppercase tracking-widest text-muted-foreground ml-1" htmlFor="role">Terminal Role</label>
                <Select value={role} onValueChange={setRole}>
                  <SelectTrigger className="bg-muted/50 border-white/5 h-12 focus:ring-primary/50">
                    <SelectValue placeholder="Select Access Role" />
                  </SelectTrigger>
                  <SelectContent className="glass-panel border-white/10">
                    {systemRoles.map((r) => (
                      <SelectItem key={r.id} value={r.id}>
                        <div className="flex items-center gap-2">
                          <r.icon className={`h-4 w-4 ${r.color}`} />
                          <span>{r.name}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid gap-2">
                <label className="text-xs font-bold uppercase tracking-widest text-muted-foreground ml-1" htmlFor="email">Identity Email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="admin@privacysense.com"
                    className="pl-10 bg-muted/50 border-white/5 h-11 focus:ring-primary/50"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
              </div>

              <div className="grid gap-2">
                <label className="text-xs font-bold uppercase tracking-widest text-muted-foreground ml-1" htmlFor="password">Access Credential</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="password"
                    type="password"
                    placeholder="••••••••"
                    className="pl-10 bg-muted/50 border-white/5 h-11 focus:ring-primary/50"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter className="pt-2 pb-8">
              <Button 
                className="w-full h-12 font-bold text-base transition-all hover:scale-[1.01] shadow-lg shadow-primary/20 group" 
                type="submit"
                disabled={isLoading || isUserLoading}
              >
                {isLoading ? "Validating Identity..." : (
                  <>
                    Establish Secure Session
                    <ChevronRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </>
                )}
              </Button>
            </CardFooter>
          </form>
        </Card>

        <div className="p-5 rounded-2xl border border-white/5 bg-card/30 backdrop-blur-sm space-y-4 shadow-xl">
          <div className="flex items-center gap-2 mb-2">
            <Info className="h-4 w-4 text-primary" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Access Policy Definitions</span>
          </div>
          <div className="space-y-4">
            {systemRoles.map((role) => (
              <div key={role.name} className="flex gap-4 group cursor-default">
                <div className={`p-2 rounded-xl bg-white/5 border border-white/5 h-fit ${role.color} group-hover:bg-white/10 transition-colors`}>
                  <role.icon className="h-4 w-4" />
                </div>
                <div className="space-y-1">
                  <p className="text-xs font-bold leading-none tracking-tight">{role.name} Profile</p>
                  <p className="text-[11px] text-muted-foreground leading-relaxed opacity-80">{role.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <p className="text-[10px] text-center text-muted-foreground/30 px-12 leading-relaxed uppercase tracking-tighter">
          Proprietary System: PrivacySense Core. All authentication events are recorded for DPDPA 2023 forensic auditing.
        </p>
      </div>
    </div>
  );
}
