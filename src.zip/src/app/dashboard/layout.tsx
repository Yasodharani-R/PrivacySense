
"use client";

import { useEffect, useState } from "react";
import { useRouter, usePathname } from "next/navigation";
import { 
  LayoutDashboard, 
  Users, 
  Search, 
  Database, 
  History, 
  FileText, 
  Settings, 
  LogOut, 
  ShieldCheck,
  Bell,
  Search as SearchIcon,
  Shield
} from "lucide-react";
import { useUser, useAuth, useDoc, useMemoFirebase, useFirestore } from "@/firebase";
import { Sidebar, SidebarContent, SidebarFooter, SidebarHeader, SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarProvider, SidebarTrigger, SidebarInset } from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { doc } from "firebase/firestore";

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const auth = useAuth();
  const db = useFirestore();
  const { user, isUserLoading } = useUser();
  const [mounted, setMounted] = useState(false);

  // Fetch the extended user profile to get the role
  const userDocRef = useMemoFirebase(() => {
    if (!db || !user?.uid) return null;
    return doc(db, 'users', user.uid);
  }, [db, user?.uid]);
  
  const { data: userProfile, isLoading: isProfileLoading } = useDoc(userDocRef);

  useEffect(() => {
    setMounted(true);
    if (!isUserLoading && !user) {
      router.push("/");
    }
  }, [user, isUserLoading, router]);

  if (!mounted || isUserLoading || !user) return null;

  // Default role to Employee if profile not yet loaded/found
  const role = userProfile?.role || 'Employee';
  const userName = userProfile?.name || user.email?.split('@')[0] || 'User';

  const navigation = [
    { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard, roles: ['Admin', 'Manager', 'Employee'] },
    { name: 'Data Discovery', href: '/dashboard/discovery', icon: Search, roles: ['Admin', 'Manager'] },
    { name: 'Data Inventory', href: '/dashboard/inventory', icon: Database, roles: ['Admin', 'Manager', 'Employee'] },
    { name: 'Classification Policy', href: '/dashboard/classifications', icon: Shield, roles: ['Admin', 'Manager', 'Employee'] },
    { name: 'User Management', href: '/dashboard/users', icon: Users, roles: ['Admin'] },
    { name: 'Activity Logs', href: '/dashboard/logs', icon: History, roles: ['Admin', 'Manager', 'Employee'] },
    { name: 'Compliance Reports', href: '/dashboard/reports', icon: FileText, roles: ['Admin', 'Manager'] },
    { name: 'System Settings', href: '/dashboard/settings', icon: Settings, roles: ['Admin'] },
  ];

  const filteredNav = navigation.filter(item => item.roles.includes(role));

  const handleLogout = () => {
    auth.signOut().then(() => {
      router.push("/");
    });
  };

  return (
    <SidebarProvider>
      <div className="flex h-screen w-full bg-background overflow-hidden">
        <Sidebar variant="inset" collapsible="icon">
          <SidebarHeader className="h-16 flex items-center px-6 border-b border-white/5">
            <div className="flex items-center gap-3">
              <ShieldCheck className="h-6 w-6 text-primary shrink-0" />
              <span className="font-bold text-lg tracking-tight gradient-text group-data-[collapsible=icon]:hidden">PrivacySense</span>
            </div>
          </SidebarHeader>
          <SidebarContent className="p-2">
            <SidebarMenu>
              {filteredNav.map((item) => (
                <SidebarMenuItem key={item.name}>
                  <SidebarMenuButton 
                    asChild 
                    isActive={pathname === item.href}
                    tooltip={item.name}
                  >
                    <a href={item.href} className="flex items-center gap-3">
                      <item.icon className="h-5 w-5" />
                      <span>{item.name}</span>
                    </a>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarContent>
          <SidebarFooter className="p-4 border-t border-white/5">
            <div className="flex items-center gap-3 group-data-[collapsible=icon]:hidden">
              <Avatar className="h-9 w-9 border border-white/10">
                <AvatarFallback className="bg-primary/20 text-primary">{userName[0]?.toUpperCase()}</AvatarFallback>
              </Avatar>
              <div className="flex flex-col min-w-0">
                <span className="text-sm font-medium truncate">{userName}</span>
                <span className="text-xs text-muted-foreground uppercase">{role}</span>
              </div>
              <Button variant="ghost" size="icon" onClick={handleLogout} className="ml-auto text-muted-foreground hover:text-destructive">
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </SidebarFooter>
        </Sidebar>

        <SidebarInset className="flex flex-col flex-1 overflow-hidden">
          <header className="h-16 flex items-center justify-between px-6 border-b border-white/5 bg-background/50 backdrop-blur-sm sticky top-0 z-10">
            <div className="flex items-center gap-4">
              <SidebarTrigger />
              <div className="h-6 w-px bg-white/10 hidden sm:block" />
              <div className="relative hidden md:block">
                <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <input 
                  type="text" 
                  placeholder="Search data records..." 
                  className="h-9 w-64 bg-muted/50 border border-white/5 rounded-md pl-9 pr-4 text-sm focus:outline-none focus:ring-1 focus:ring-primary transition-all"
                />
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" className="relative text-muted-foreground">
                <Bell className="h-5 w-5" />
                <span className="absolute top-2 right-2.5 h-2 w-2 bg-destructive rounded-full" />
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                    <Avatar className="h-8 w-8 border border-white/10">
                      <AvatarFallback className="bg-primary/20 text-primary">{userName[0]?.toUpperCase()}</AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end" forceMount>
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none">{userName}</p>
                      <p className="text-xs leading-none text-muted-foreground">{user.email}</p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => router.push('/dashboard/profile')}>Profile</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => router.push('/dashboard/settings')}>Settings</DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} className="text-destructive">Log out</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </header>
          <main className="flex-1 overflow-y-auto p-6 scroll-smooth">
            {children}
          </main>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
}
