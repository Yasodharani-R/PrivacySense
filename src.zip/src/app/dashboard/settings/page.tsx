
"use client";

import { Settings, Shield, Bell, Lock, Database, Globe, Save } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";

export default function SettingsPage() {
  const { toast } = useToast();

  const handleSave = () => {
    toast({
      title: "Settings Saved",
      description: "System configuration has been updated successfully.",
    });
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div className="flex flex-col gap-1">
        <h1 className="text-3xl font-bold tracking-tight">System Settings</h1>
        <p className="text-muted-foreground">Global configuration for PrivacySense discovery engine and enterprise policy.</p>
      </div>

      <div className="grid gap-6">
        <Card className="border-white/5 glass-panel">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              <CardTitle>Discovery Engine Policy</CardTitle>
            </div>
            <CardDescription>Configure how the AI engine identifies and tags sensitive data.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <label className="text-sm font-medium">Auto-Classification</label>
                <p className="text-xs text-muted-foreground">Automatically tag new data elements using LLM inference.</p>
              </div>
              <Switch defaultChecked />
            </div>
            <Separator className="bg-white/5" />
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <label className="text-sm font-medium">Confidence Threshold</label>
                <p className="text-xs text-muted-foreground">Minimum AI confidence score required for automatic tagging (0.85 recommended).</p>
              </div>
              <Input className="w-20 bg-muted/30 border-white/5" defaultValue="0.85" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-white/5 glass-panel">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Bell className="h-5 w-5 text-primary" />
              <CardTitle>Security Alerts</CardTitle>
            </div>
            <CardDescription>Manage system notifications for compliance breaches and unauthorized access.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <label className="text-sm font-medium">Critical Data Exposure Alerts</label>
                <p className="text-xs text-muted-foreground">Notify DPOs immediately when Highly Sensitive Data is found in public buckets.</p>
              </div>
              <Switch defaultChecked />
            </div>
            <Separator className="bg-white/5" />
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <label className="text-sm font-medium">Daily Audit Digest</label>
                <p className="text-xs text-muted-foreground">Receive a summarized report of all system activities every 24 hours.</p>
              </div>
              <Switch />
            </div>
          </CardContent>
        </Card>

        <Card className="border-white/5 glass-panel border-destructive/20 bg-destructive/5">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Database className="h-5 w-5 text-destructive" />
              <CardTitle className="text-destructive">Danger Zone</CardTitle>
            </div>
            <CardDescription>Irreversible system actions and data purging.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <label className="text-sm font-medium">Purge Scan History</label>
                <p className="text-xs text-muted-foreground">Delete all past discovery results and audit reports older than 90 days.</p>
              </div>
              <Button variant="destructive" size="sm">Purge Records</Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-end pt-4">
        <Button onClick={handleSave} className="gap-2">
          <Save className="h-4 w-4" />
          Save Configuration
        </Button>
      </div>
    </div>
  );
}
