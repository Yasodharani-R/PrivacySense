"use client";

import { Database, HardDrive, Cloud, Mail, AlertCircle, ShieldAlert } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

const inventory = [
  { source: 'AWS S3 Bucket', type: 'Unstructured', owner: 'Engineering', sensitivity: 'High', location: 'Cloud Storage', risk: 82 },
  { source: 'Corporate DB', type: 'SQL Database', owner: 'Finance', sensitivity: 'Critical', location: 'On-Premise', risk: 94 },
  { source: 'HR File Server', type: 'SMB Share', owner: 'HR', sensitivity: 'High', location: 'File Server', risk: 75 },
  { source: 'Microsoft 365', type: 'Exchange/Drive', owner: 'Company-Wide', sensitivity: 'Medium', location: 'Cloud Suite', risk: 45 },
  { source: 'Analytics Warehouse', type: 'BigQuery', owner: 'Marketing', sensitivity: 'Low', location: 'GCP Analytics', risk: 22 },
];

export default function InventoryPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight">Data Inventory</h1>
        <p className="text-muted-foreground">Centralized mapping of personal data across storage environments.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <Card className="lg:col-span-1 border-white/5 glass-panel">
          <CardHeader>
            <CardTitle className="text-lg">Storage Mix</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
             <div className="space-y-2">
                <div className="flex justify-between text-xs font-medium uppercase tracking-wider text-muted-foreground">
                   <div className="flex items-center gap-2"><Cloud className="h-3 w-3" /> Cloud</div>
                   <span>45%</span>
                </div>
                <Progress value={45} className="h-1.5 bg-white/5" />
             </div>
             <div className="space-y-2">
                <div className="flex justify-between text-xs font-medium uppercase tracking-wider text-muted-foreground">
                   <div className="flex items-center gap-2"><HardDrive className="h-3 w-3" /> On-Premise</div>
                   <span>35%</span>
                </div>
                <Progress value={35} className="h-1.5 bg-white/5" />
             </div>
             <div className="space-y-2">
                <div className="flex justify-between text-xs font-medium uppercase tracking-wider text-muted-foreground">
                   <div className="flex items-center gap-2"><Mail className="h-3 w-3" /> SaaS/Email</div>
                   <span>20%</span>
                </div>
                <Progress value={20} className="h-1.5 bg-white/5" />
             </div>
          </CardContent>
        </Card>

        <div className="lg:col-span-3 space-y-4">
           {inventory.map((item, idx) => (
             <Card key={idx} className="border-white/5 glass-panel transition-all hover:border-primary/30 group">
               <CardContent className="p-4">
                 <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                   <div className="flex items-center gap-4">
                     <div className="p-3 bg-muted rounded-xl group-hover:bg-primary/10 transition-colors">
                       <Database className="h-6 w-6 text-muted-foreground group-hover:text-primary" />
                     </div>
                     <div>
                       <h3 className="font-bold text-lg">{item.source}</h3>
                       <p className="text-sm text-muted-foreground">{item.location} • {item.owner}</p>
                     </div>
                   </div>
                   <div className="flex flex-wrap items-center gap-3">
                     <Badge variant="outline" className="border-white/5 bg-white/5 text-[10px] uppercase">{item.type}</Badge>
                     <Badge 
                        variant="outline" 
                        className={`text-[10px] uppercase font-bold tracking-tighter ${
                          item.sensitivity === 'Critical' ? 'bg-destructive/10 text-destructive border-destructive/20' : 
                          item.sensitivity === 'High' ? 'bg-amber-500/10 text-amber-500 border-amber-500/20' : 
                          'bg-primary/10 text-primary border-primary/20'
                        }`}
                      >
                       {item.sensitivity} Sensitivity
                     </Badge>
                     <div className="w-32">
                        <div className="flex justify-between text-[10px] mb-1 text-muted-foreground">
                          <span>RISK SCORE</span>
                          <span className={item.risk > 80 ? "text-destructive" : ""}>{item.risk}%</span>
                        </div>
                        <Progress value={item.risk} className={`h-1 ${item.risk > 80 ? "[&>div]:bg-destructive" : ""}`} />
                     </div>
                   </div>
                 </div>
               </CardContent>
             </Card>
           ))}
        </div>
      </div>
    </div>
  );
}