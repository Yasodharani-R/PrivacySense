
"use client";

import { User, Mail, Shield, Building2, Calendar, Fingerprint, Lock, ShieldCheck } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useUser, useFirestore, useDoc, useMemoFirebase } from "@/firebase";
import { doc } from "firebase/firestore";

export default function ProfilePage() {
  const { user } = useUser();
  const db = useFirestore();

  const userDocRef = useMemoFirebase(() => {
    if (!db || !user?.uid) return null;
    return doc(db, 'users', user.uid);
  }, [db, user?.uid]);

  const { data: profile, isLoading } = useDoc(userDocRef);

  if (isLoading) return <div className="p-12 text-center text-muted-foreground animate-pulse">Loading identity profile...</div>;

  const userName = profile?.name || user?.email?.split('@')[0] || 'User';
  const userRole = profile?.role || 'Employee';

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <div className="flex items-center gap-6 pb-4 border-b border-white/5">
        <Avatar className="h-24 w-24 border-4 border-white/5">
          <AvatarFallback className="text-4xl bg-primary/20 text-primary">
            {userName[0]?.toUpperCase()}
          </AvatarFallback>
        </Avatar>
        <div className="space-y-1">
          <div className="flex items-center gap-3">
            <h1 className="text-4xl font-bold tracking-tight">{userName}</h1>
            <Badge className="bg-primary/10 text-primary border-primary/20 uppercase text-[10px] tracking-widest px-3 py-1">
              {userRole}
            </Badge>
          </div>
          <p className="text-muted-foreground flex items-center gap-2">
            <Mail className="h-4 w-4" /> {user?.email}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-2 border-white/5 glass-panel">
          <CardHeader>
            <CardTitle className="text-lg">Identity Details</CardTitle>
            <CardDescription>Information registered in the enterprise directory.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
              <div className="space-y-1.5">
                <p className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                  <Building2 className="h-3 w-3" /> Department
                </p>
                <p className="text-sm font-medium">{profile?.department || 'Unassigned'}</p>
              </div>
              <div className="space-y-1.5">
                <p className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                  <Fingerprint className="h-3 w-3" /> System ID
                </p>
                <p className="text-[11px] font-mono text-muted-foreground truncate">{user?.uid}</p>
              </div>
              <div className="space-y-1.5">
                <p className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                  <ShieldCheck className="h-3 w-3" /> Access Level
                </p>
                <p className="text-sm font-medium">Standard DPDPA Protocol</p>
              </div>
              <div className="space-y-1.5">
                <p className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                  <Calendar className="h-3 w-3" /> Member Since
                </p>
                <p className="text-sm font-medium">May 2024</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-white/5 glass-panel">
          <CardHeader>
            <CardTitle className="text-lg">Security Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="p-3 rounded-xl bg-white/5 border border-white/5 flex gap-3 items-center">
                <div className="p-2 bg-emerald-500/10 rounded-lg">
                  <Lock className="h-4 w-4 text-emerald-500" />
                </div>
                <div>
                  <p className="text-xs font-bold leading-none">MFA Active</p>
                  <p className="text-[10px] text-muted-foreground mt-1">Verified via Microsoft 365</p>
                </div>
              </div>
              <div className="p-3 rounded-xl bg-white/5 border border-white/5 flex gap-3 items-center">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Shield className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <p className="text-xs font-bold leading-none">Role Authorization</p>
                  <p className="text-[10px] text-muted-foreground mt-1">Validated by System Admin</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
