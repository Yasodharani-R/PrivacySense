
"use client";

import { Shield, ShieldAlert, ShieldCheck, Info, Fingerprint, Lock, ShieldEllipsis } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

const classificationDefinitions = [
  {
    name: "Highly Sensitive Data",
    level: 3,
    color: "destructive",
    icon: ShieldAlert,
    description: "Data that, if compromised, could lead to significant harm, discrimination, or financial loss to the data principal.",
    examples: ["Aadhaar Numbers", "PAN Numbers", "Bank Account Details", "Medical History", "Biometric Data", "Passwords"],
    rules: "Must be encrypted at rest, masked in UI, and subject to strict multi-factor access control."
  },
  {
    name: "Personal Data",
    level: 2,
    color: "primary",
    icon: ShieldCheck,
    description: "Any data relating to an identified or identifiable individual that is not categorized as highly sensitive.",
    examples: ["Full Name", "Email Address", "Phone Number", "Residential Address", "Date of Birth", "Employee ID"],
    rules: "Access limited to authorized personnel with a clear 'need-to-know' basis for business processing."
  },
  {
    name: "General Data",
    level: 1,
    color: "secondary",
    icon: ShieldEllipsis,
    description: "Information that does not contain identifiers or is already in the public domain.",
    examples: ["Public Business Contact Info", "Anonymized Statistics", "General Company Policies", "Public Press Releases"],
    rules: "Standard internal security controls apply. No specific DPDPA individual protection requirements."
  }
];

export default function ClassificationsPage() {
  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight">Data Classification Policy</h1>
        <p className="text-muted-foreground">Framework for identifying and protecting sensitive identifiers as per DPDPA 2023.</p>
      </div>

      <Alert className="bg-primary/5 border-primary/20">
        <Info className="h-4 w-4 text-primary" />
        <AlertTitle className="text-primary font-bold">DPDPA 2023 Compliance</AlertTitle>
        <AlertDescription className="text-sm text-muted-foreground">
          The following classifications are used by the Discovery Engine to automatically tag data elements. These labels dictate the retention, encryption, and access policies enforced across the enterprise.
        </AlertDescription>
      </Alert>

      <div className="grid grid-cols-1 gap-6">
        {classificationDefinitions.map((item) => (
          <Card key={item.name} className="border-white/5 glass-panel overflow-hidden">
            <div className="flex flex-col md:flex-row h-full">
              <div className={`w-full md:w-2 ${item.name === 'Highly Sensitive Data' ? 'bg-destructive' : item.name === 'Personal Data' ? 'bg-primary' : 'bg-secondary'}`} />
              <div className="flex-1 p-6">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                  <div className="flex items-center gap-4">
                    <div className={`p-3 rounded-xl bg-white/5 border border-white/5`}>
                      <item.icon className={`h-6 w-6 ${item.name === 'Highly Sensitive Data' ? 'text-destructive' : item.name === 'Personal Data' ? 'text-primary' : 'text-secondary'}`} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h2 className="text-xl font-bold tracking-tight">{item.name}</h2>
                        <Badge variant="outline" className="text-[10px] h-5">LEVEL {item.level}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{item.description}</p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-3">
                    <h3 className="text-xs font-bold uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                      <Fingerprint className="h-3 w-3" /> Targeted Identifiers
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      {item.examples.map((ex) => (
                        <Badge key={ex} variant="secondary" className="bg-white/5 hover:bg-white/10 text-xs font-normal border-white/5">
                          {ex}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h3 className="text-xs font-bold uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                      <Lock className="h-3 w-3" /> Security Requirements
                    </h3>
                    <p className="text-sm text-muted-foreground italic leading-relaxed">
                      {item.rules}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <Card className="border-white/5 glass-panel bg-muted/20">
        <CardHeader>
          <CardTitle className="text-lg">Classification Automation</CardTitle>
          <CardDescription>How our engine determines classification</CardDescription>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground space-y-4">
          <p>
            The PrivacySense Discovery Engine uses a specialized Large Language Model (Gemini 2.5) configured with DPDPA 2023 legal guidelines. When a scan is initiated, the engine:
          </p>
          <ol className="list-decimal list-inside space-y-2 ml-4">
            <li>Extracts raw text data from the target repository.</li>
            <li>Identifies PII patterns (Aadhaar, PAN, Names, etc.).</li>
            <li>Analyzes the context of the data to determine sensitivity.</li>
            <li>Applies the appropriate classification tag based on the definitions above.</li>
          </ol>
        </CardContent>
      </Card>
    </div>
  );
}
