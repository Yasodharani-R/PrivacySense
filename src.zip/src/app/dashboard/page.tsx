"use client";

import { useUser, useFirestore, useDoc, useMemoFirebase } from "@/firebase";
import { doc } from "firebase/firestore";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip as RechartsTooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell,
} from "recharts";
import { 
  ShieldAlert, 
  ShieldCheck, 
  ArrowUpRight, 
  AlertTriangle,
  Fingerprint,
  FileSearch,
  Activity,
  Shield,
  Zap
} from "lucide-react";

const stats = [
  { label: "Detected PII", value: "1,248", icon: Fingerprint, color: "text-primary", bg: "bg-primary/10", trend: "+12%" },
  { label: "Highly Sensitive", value: "342", icon: ShieldAlert, color: "text-destructive", bg: "bg-destructive/10", trend: "+5%" },
  { label: "Avg. Risk Score", value: "24", icon: AlertTriangle, color: "text-amber-500", bg: "bg-amber-500/10", trend: "-2%" },
  { label: "Scanned Records", value: "84.2k", icon: FileSearch, color: "text-secondary", bg: "bg-secondary/10", trend: "+18%" },
];

const distributionData = [
  { name: 'Financial', value: 400 },
  { name: 'Identity', value: 300 },
  { name: 'Health', value: 200 },
  { name: 'Contact', value: 278 },
];

const exposureData = [
  { name: 'HR', score: 85 },
  { name: 'IT', score: 45 },
  { name: 'Sales', score: 30 },
  { name: 'Finance', score: 95 },
  { name: 'Support', score: 20 },
];

const COLORS = ['#677CE4', '#B7A6D9', '#4f46e5', '#8b5cf6'];

export default function DashboardPage() {
  const { user } = useUser();
  const db = useFirestore();

  const userDocRef = useMemoFirebase(() => {
    if (!db || !user?.uid) return null;
    return doc(db, 'users', user.uid);
  }, [db, user?.uid]);
  
  const { data: profile } = useDoc(userDocRef);

  const userName = profile?.name || user?.email?.split('@')[0] || 'User';
  const userRole = profile?.role || 'Employee';

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-4xl font-extrabold tracking-tight">Security Overview</h1>
          <p className="text-muted-foreground flex items-center gap-2">
            <ShieldCheck className="h-4 w-4 text-emerald-500" />
            Welcome back, <span className="text-foreground font-semibold">{userName}</span> • 
            <span className="text-xs uppercase tracking-widest ml-1 font-bold text-primary">{userRole} ACCESS</span>
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex -space-x-2">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-8 w-8 rounded-full border-2 border-background bg-muted flex items-center justify-center text-[10px] font-bold">
                {String.fromCharCode(64 + i)}
              </div>
            ))}
          </div>
          <p className="text-xs text-muted-foreground font-medium">3 Active Auditors</p>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.label} className="border-white/5 glass-panel hover:border-primary/20 transition-all duration-300 group">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-xs font-bold uppercase tracking-[0.1em] text-muted-foreground">{stat.label}</CardTitle>
              <div className={`${stat.bg} p-2 rounded-xl group-hover:scale-110 transition-transform`}>
                <stat.icon className={`h-4 w-4 ${stat.color}`} />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-black tracking-tight">{stat.value}</div>
              <p className="text-xs mt-2 flex items-center gap-1 font-semibold">
                <ArrowUpRight className={`h-3 w-3 ${stat.trend.startsWith('+') ? 'text-emerald-500' : 'text-primary'}`} />
                <span className={stat.trend.startsWith('+') ? 'text-emerald-500' : 'text-primary'}>{stat.trend}</span> 
                <span className="text-muted-foreground font-normal ml-1">vs last period</span>
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-7">
        <Card className="lg:col-span-4 border-white/5 glass-panel overflow-hidden">
          <CardHeader className="border-b border-white/5 bg-white/5 pb-4">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg">Departmental Risk Index</CardTitle>
                <CardDescription>Sensitivity levels by organizational unit</CardDescription>
              </div>
              <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">Live Sync</Badge>
            </div>
          </CardHeader>
          <CardContent className="h-[350px] pt-8">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={exposureData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#ffffff10" />
                <XAxis 
                  dataKey="name" 
                  stroke="#888888" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                  dy={10}
                />
                <YAxis 
                  stroke="#888888" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                  tickFormatter={(value) => `${value}`} 
                />
                <RechartsTooltip 
                  cursor={{fill: '#ffffff05'}}
                  contentStyle={{ backgroundColor: '#21222C', border: '1px solid #ffffff10', borderRadius: '12px', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.5)' }}
                />
                <Bar dataKey="score" fill="url(#colorPrimary)" radius={[6, 6, 0, 0]} barSize={40} />
                <defs>
                  <linearGradient id="colorPrimary" x1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#677CE4" stopOpacity={0.9}/>
                    <stop offset="100%" stopColor="#677CE4" stopOpacity={0.1}/>
                  </linearGradient>
                </defs>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="lg:col-span-3 border-white/5 glass-panel overflow-hidden">
          <CardHeader className="border-b border-white/5 bg-white/5 pb-4">
            <CardTitle className="text-lg">Data Composition</CardTitle>
            <CardDescription>PII identifier categories distribution</CardDescription>
          </CardHeader>
          <CardContent className="h-[350px] pt-4">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={distributionData}
                  cx="50%"
                  cy="50%"
                  innerRadius={80}
                  outerRadius={100}
                  paddingAngle={8}
                  dataKey="value"
                  stroke="none"
                >
                  {distributionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <RechartsTooltip 
                  contentStyle={{ backgroundColor: '#21222C', border: '1px solid #ffffff10', borderRadius: '12px' }}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex flex-wrap justify-center gap-x-6 gap-y-2 mt-2 px-4">
              {distributionData.map((item, i) => (
                <div key={item.name} className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                  <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{item.name}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card className="border-white/5 glass-panel bg-gradient-to-br from-primary/5 to-transparent">
          <CardHeader>
            <div className="flex items-center gap-2 mb-2">
              <Zap className="h-4 w-4 text-primary" />
              <CardTitle className="text-sm font-bold uppercase tracking-widest text-primary">System Health</CardTitle>
            </div>
            <div className="flex justify-between items-end">
              <div className="text-3xl font-black">99.8%</div>
              <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20 text-[10px]">OPTIMAL</Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-[10px] font-bold uppercase text-muted-foreground">
                <span>Engine Latency</span>
                <span>45ms</span>
              </div>
              <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                <div className="bg-primary w-[15%] h-full" />
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-[10px] font-bold uppercase text-muted-foreground">
                <span>Auth Cluster</span>
                <span>Online</span>
              </div>
              <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                <div className="bg-emerald-500 w-[95%] h-full" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2 border-white/5 glass-panel">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-lg">Real-time Audit Feed</CardTitle>
              <CardDescription>Latest compliance events across the enterprise</CardDescription>
            </div>
            <Button variant="ghost" size="sm" className="text-xs text-primary font-bold hover:bg-primary/10">View Full Trail</Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-1">
              {[
                { event: "New PII Detected", source: "HR-DB Cluster", time: "12m ago", type: "Discovery", icon: Activity },
                { event: "Audit Log Exported", source: "Admin Console", time: "44m ago", type: "Security", icon: Shield },
                { event: "Scan Scheduled", source: "AWS-S3 Bucket", time: "2h ago", type: "System", icon: Zap },
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-4 p-3 rounded-xl hover:bg-white/5 transition-colors group cursor-default">
                  <div className="p-2.5 bg-muted rounded-xl group-hover:bg-primary/20 transition-colors">
                    <item.icon className="h-4 w-4 text-muted-foreground group-hover:text-primary" />
                  </div>
                  <div className="flex-1 space-y-0.5">
                    <p className="text-sm font-bold leading-none">{item.event}</p>
                    <p className="text-xs text-muted-foreground">{item.source} • <span className="opacity-60">{item.time}</span></p>
                  </div>
                  <Badge variant="outline" className="text-[9px] h-5 border-white/10 uppercase font-bold text-muted-foreground">
                    {item.type}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}