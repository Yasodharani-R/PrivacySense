"use client";

import { useState } from "react";
import { 
  ShieldCheck, 
  User, 
  Laptop, 
  Globe, 
  AlertTriangle, 
  FileCheck,
  Search,
  Filter,
  ArrowDownToLine,
  ShieldAlert,
  History
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const auditLogs = [
  { id: 1, event: 'User Login', user: 'admin@privacysense.com', status: 'Success', ip: '192.168.1.1', device: 'Windows 11 / Chrome', time: '2024-05-20 10:45:12', type: 'Authorized' },
  { id: 2, event: 'Data Discovery Run', user: 'sarah@privacysense.com', status: 'Success', ip: '10.0.4.55', device: 'MacOS / Safari', time: '2024-05-20 11:20:05', type: 'Authorized' },
  { id: 3, event: 'Unauthorized Access Attempt', user: 'unknown@external.net', status: 'Blocked', ip: '45.77.12.190', device: 'Linux / Unknown', time: '2024-05-20 12:05:44', type: 'Unauthorized' },
  { id: 4, event: 'Policy Update', user: 'admin@privacysense.com', status: 'Success', ip: '192.168.1.1', device: 'Windows 11 / Chrome', time: '2024-05-20 14:15:22', type: 'Authorized' },
  { id: 5, event: 'Report Generation', user: 'michael@privacysense.com', status: 'Success', ip: '10.0.4.12', device: 'iOS / App', time: '2024-05-20 15:30:10', type: 'Authorized' },
  { id: 6, event: 'Failed Admin Login', user: 'root@internal', status: 'Blocked', ip: '172.16.0.4', device: 'Python/Requests', time: '2024-05-20 16:12:00', type: 'Unauthorized' },
  { id: 7, event: 'Restricted Data Query', user: 'operator_4@corp', status: 'Blocked', ip: '10.0.5.22', device: 'Windows 10 / Firefox', time: '2024-05-20 16:45:33', type: 'Unauthorized' },
  { id: 8, event: 'Log Export', user: 'admin@privacysense.com', status: 'Success', ip: '192.168.1.1', device: 'Windows 11 / Chrome', time: '2024-05-20 17:05:12', type: 'Authorized' },
];

export default function LogsPage() {
  const [searchTerm, setSearchTerm] = useState("");

  const authorizedLogs = auditLogs.filter(log => log.type === 'Authorized' && (
    log.event.toLowerCase().includes(searchTerm.toLowerCase()) ||
    log.user.toLowerCase().includes(searchTerm.toLowerCase())
  ));

  const unauthorizedLogs = auditLogs.filter(log => log.type === 'Unauthorized' && (
    log.event.toLowerCase().includes(searchTerm.toLowerCase()) ||
    log.user.toLowerCase().includes(searchTerm.toLowerCase())
  ));

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-col gap-1">
          <h1 className="text-3xl font-bold tracking-tight">Audit & Compliance Logs</h1>
          <p className="text-muted-foreground">Detailed activity trails for DPDPA 2023 compliance auditing.</p>
        </div>
        <Button variant="outline" className="border-white/5 bg-white/5">
          <ArrowDownToLine className="h-4 w-4 mr-2" />
          Export Audit Trail
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-white/5 glass-panel">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Unauthorized Attempts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <span className="text-3xl font-bold text-destructive">{unauthorizedLogs.length}</span>
              <div className="p-2 bg-destructive/10 rounded-lg">
                <ShieldAlert className="h-5 w-5 text-destructive" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-white/5 glass-panel">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Authorized Operations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <span className="text-3xl font-bold text-primary">{authorizedLogs.length}</span>
              <div className="p-2 bg-primary/10 rounded-lg">
                <ShieldCheck className="h-5 w-5 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-white/5 glass-panel">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Last Audit Check</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <span className="text-xl font-bold">14 mins ago</span>
              <div className="p-2 bg-emerald-500/10 rounded-lg">
                <FileCheck className="h-5 w-5 text-emerald-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-white/5 glass-panel overflow-hidden">
        <Tabs defaultValue="authorized" className="w-full">
          <CardHeader className="pb-3 space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <TabsList className="bg-muted/30 border border-white/5">
                <TabsTrigger value="authorized" className="flex items-center gap-2">
                  <History className="h-3.5 w-3.5" />
                  Authorized Activity
                </TabsTrigger>
                <TabsTrigger value="unauthorized" className="flex items-center gap-2 text-destructive data-[state=active]:text-destructive">
                  <ShieldAlert className="h-3.5 w-3.5" />
                  Security Alerts
                  <Badge variant="destructive" className="ml-1 h-4 px-1 text-[8px]">{unauthorizedLogs.length}</Badge>
                </TabsTrigger>
              </TabsList>
              
              <div className="relative w-full md:w-72">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input 
                  placeholder="Filter logs..." 
                  className="pl-9 bg-muted/20 border-white/5 h-9"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
          </CardHeader>

          <CardContent className="p-0">
            <TabsContent value="authorized" className="m-0">
              <LogTable logs={authorizedLogs} />
            </TabsContent>
            <TabsContent value="unauthorized" className="m-0">
              <LogTable logs={unauthorizedLogs} isAlert />
            </TabsContent>
          </CardContent>
        </Tabs>
      </Card>
    </div>
  );
}

function LogTable({ logs, isAlert = false }: { logs: typeof auditLogs, isAlert?: boolean }) {
  if (logs.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center space-y-4">
        <div className="p-4 bg-muted/30 rounded-full">
          <Search className="h-8 w-8 text-muted-foreground opacity-20" />
        </div>
        <div>
          <h3 className="text-lg font-bold">No logs found</h3>
          <p className="text-sm text-muted-foreground max-w-xs">Try adjusting your search or filter to find specific audit events.</p>
        </div>
      </div>
    );
  }

  return (
    <Table>
      <TableHeader className="bg-muted/20 border-white/5">
        <TableRow className="hover:bg-transparent">
          <TableHead className="w-[250px]">Event Description</TableHead>
          <TableHead>Principal Identity</TableHead>
          <TableHead>Connectivity</TableHead>
          <TableHead>Timestamp</TableHead>
          <TableHead className="text-right">Risk Level</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {logs.map((log) => (
          <TableRow key={log.id} className="border-white/5 hover:bg-white/5 transition-colors">
            <TableCell>
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg ${isAlert ? 'bg-destructive/10' : 'bg-primary/10'}`}>
                  {isAlert ? <AlertTriangle className="h-4 w-4 text-destructive" /> : <ShieldCheck className="h-4 w-4 text-primary" />}
                </div>
                <div className="flex flex-col">
                  <span className="font-semibold text-sm">{log.event}</span>
                  <span className="text-[10px] text-muted-foreground uppercase tracking-tight">{log.status}</span>
                </div>
              </div>
            </TableCell>
            <TableCell>
              <div className="flex flex-col">
                <span className="text-sm font-medium">{log.user}</span>
                <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                  <Laptop className="h-3 w-3" /> {log.device}
                </span>
              </div>
            </TableCell>
            <TableCell>
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground font-mono">
                <Globe className="h-3 w-3 text-primary/50" />
                {log.ip}
              </div>
            </TableCell>
            <TableCell className="text-xs text-muted-foreground font-mono">
              {log.time}
            </TableCell>
            <TableCell className="text-right">
              <Badge 
                variant="outline" 
                className={`text-[10px] font-bold tracking-widest ${
                  isAlert ? 'text-destructive border-destructive/20 bg-destructive/5' : 'text-primary border-primary/20 bg-primary/5'
                }`}
              >
                {isAlert ? 'CRITICAL' : 'LOW RISK'}
              </Badge>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
