
"use client";

import { useState } from "react";
import { UserPlus, Search, Shield, Trash2, Edit2, ShieldAlert, Lock, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useUser, useFirestore, useCollection, useMemoFirebase, useDoc } from "@/firebase";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { collection, doc } from "firebase/firestore";
import { setDocumentNonBlocking, deleteDocumentNonBlocking } from "@/firebase/non-blocking-updates";
import { initializeApp, deleteApp } from "firebase/app";
import { getAuth, createUserWithEmailAndPassword, signOut } from "firebase/auth";
import { firebaseConfig } from "@/firebase/config";

export default function UserManagementPage() {
  const { user: currentUser } = useUser();
  const db = useFirestore();
  const { toast } = useToast();
  
  const [searchTerm, setSearchTerm] = useState("");
  const [isAddingUser, setIsAddingUser] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isEditingUser, setIsEditingUser] = useState(false);
  const [newUser, setNewUser] = useState({ name: "", email: "", role: "Employee", department: "", password: "" });
  const [editingUser, setEditingUser] = useState<any>(null);

  // Fetch current user profile to verify Admin role
  const currentUserDocRef = useMemoFirebase(() => {
    if (!db || !currentUser?.uid) return null;
    return doc(db, 'users', currentUser.uid);
  }, [db, currentUser?.uid]);
  const { data: currentUserProfile, isLoading: isProfileLoading } = useDoc(currentUserDocRef);

  // Determine if user is bootstrap admin
  const isBootstrapAdmin = currentUser?.email === "admin@privacysense.com";
  const hasAdminAccess = isBootstrapAdmin || currentUserProfile?.role === "Admin";

  // Fetch all users (Admins only per rules)
  const usersCollectionRef = useMemoFirebase(() => {
    if (!db || !hasAdminAccess) return null;
    return collection(db, 'users');
  }, [db, hasAdminAccess]);
  const { data: users = [], isLoading: isUsersLoading } = useCollection(usersCollectionRef);

  if (isProfileLoading) {
    return <div className="p-8 text-center text-muted-foreground animate-pulse">Verifying administrative credentials...</div>;
  }

  if (!hasAdminAccess) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center p-12 space-y-4">
        <ShieldAlert className="h-16 w-16 text-destructive opacity-50" />
        <h2 className="text-2xl font-bold">Access Restricted</h2>
        <p className="text-muted-foreground">Only system administrators can access user management controls.</p>
        <Button onClick={() => window.history.back()}>Go Back</Button>
      </div>
    );
  }

  const handleAddUser = async () => {
    if (!newUser.name || !newUser.email || !newUser.password || !db) {
      toast({ 
        title: "Missing Information", 
        description: "Please provide all required fields, including a password.",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);
    
    try {
      // Create a secondary app to create the user without signing out the Admin
      const secondaryAppName = `secondary-${Date.now()}`;
      const secondaryApp = initializeApp(firebaseConfig, secondaryAppName);
      const secondaryAuth = getAuth(secondaryApp);

      // Create the Auth user
      const userCredential = await createUserWithEmailAndPassword(secondaryAuth, newUser.email, newUser.password);
      const newUid = userCredential.user.uid;

      // Clean up the secondary instance
      await signOut(secondaryAuth);
      await deleteApp(secondaryApp);

      // Provision the Firestore profile using the real UID
      const userDocRef = doc(db, 'users', newUid);
      const roleDocRef = doc(db, `roles_${newUser.role.toLowerCase()}`, newUid);

      setDocumentNonBlocking(userDocRef, {
        id: newUid,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role,
        department: newUser.department,
        status: 'Active',
      }, { merge: true });

      setDocumentNonBlocking(roleDocRef, { active: true }, { merge: true });

      setIsAddingUser(false);
      setNewUser({ name: "", email: "", role: "Employee", department: "", password: "" });
      toast({ 
        title: "User Provisioned", 
        description: `Account for ${newUser.name} is now active in the directory.` 
      });
    } catch (error: any) {
      toast({ 
        title: "Provisioning Failed", 
        description: error.message || "Could not create user account.", 
        variant: "destructive" 
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEditClick = (user: any) => {
    setEditingUser({ ...user });
    setIsEditingUser(true);
  };

  const handleUpdateUser = () => {
    if (!editingUser.name || !editingUser.email || !db) return;
    
    const userDocRef = doc(db, 'users', editingUser.id);
    const roleDocRef = doc(db, `roles_${editingUser.role.toLowerCase()}`, editingUser.id);

    setDocumentNonBlocking(userDocRef, {
      ...editingUser,
    }, { merge: true });
    
    setDocumentNonBlocking(roleDocRef, { active: true }, { merge: true });

    setIsEditingUser(false);
    setEditingUser(null);
    toast({ title: "User Updated", description: `Account for ${editingUser.name} has been updated.` });
  };

  const handleDeleteUser = (id: string, role: string) => {
    if (!db) return;
    const userDocRef = doc(db, 'users', id);
    const roleDocRef = doc(db, `roles_${role.toLowerCase()}`, id);

    deleteDocumentNonBlocking(userDocRef);
    deleteDocumentNonBlocking(roleDocRef);
    toast({ title: "User Deleted", variant: "destructive" });
  };

  const filteredUsers = (users || []).filter(u => 
    u.name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
    u.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-col gap-1">
          <h1 className="text-3xl font-bold tracking-tight">User Management</h1>
          <p className="text-muted-foreground">Manage organizational access and assign DPDPA compliance roles.</p>
        </div>
        <Dialog open={isAddingUser} onOpenChange={setIsAddingUser}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-2">
              <UserPlus className="h-4 w-4" />
              Create Account
            </Button>
          </DialogTrigger>
          <DialogContent className="glass-panel border-white/10 max-w-md">
            <DialogHeader>
              <DialogTitle>Add New Team Member</DialogTitle>
              <DialogDescription>
                Provision a new identity. This will create a login in the secure enterprise directory.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <label className="text-sm font-medium">Full Name</label>
                <Input 
                  placeholder="Enter full name" 
                  value={newUser.name} 
                  onChange={(e) => setNewUser({...newUser, name: e.target.value})}
                  className="bg-muted/50 border-white/5" 
                />
              </div>
              <div className="grid gap-2">
                <label className="text-sm font-medium">Work Email</label>
                <Input 
                  type="email" 
                  placeholder="name@company.com" 
                  value={newUser.email}
                  onChange={(e) => setNewUser({...newUser, email: e.target.value})}
                  className="bg-muted/50 border-white/5" 
                />
              </div>
              <div className="grid gap-2">
                <label className="text-sm font-medium flex items-center gap-2">
                  <Lock className="h-3 w-3" /> Set Password
                </label>
                <Input 
                  type="password"
                  placeholder="Minimum 6 characters" 
                  value={newUser.password}
                  onChange={(e) => setNewUser({...newUser, password: e.target.value})}
                  className="bg-muted/50 border-white/5" 
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <label className="text-sm font-medium">Role</label>
                  <Select value={newUser.role} onValueChange={(val: any) => setNewUser({...newUser, role: val})}>
                    <SelectTrigger className="bg-muted/50 border-white/5">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Admin">Admin</SelectItem>
                      <SelectItem value="Manager">Manager</SelectItem>
                      <SelectItem value="Employee">Employee</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <label className="text-sm font-medium">Department</label>
                  <Input 
                    placeholder="e.g. HR" 
                    value={newUser.department}
                    onChange={(e) => setNewUser({...newUser, department: e.target.value})}
                    className="bg-muted/50 border-white/5" 
                  />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setIsAddingUser(false)} disabled={isSubmitting}>Cancel</Button>
              <Button onClick={handleAddUser} disabled={isSubmitting}>
                {isSubmitting ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Provisioning...</> : "Create Account"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="border-white/5 glass-panel">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search by name, email or role..." 
                className="pl-9 bg-muted/30 border-white/5 w-full"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isUsersLoading ? (
            <div className="py-10 text-center text-muted-foreground italic">Synchronizing with directory...</div>
          ) : (
            <Table>
              <TableHeader className="border-white/5">
                <TableRow className="hover:bg-transparent">
                  <TableHead>User</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.map((u) => (
                  <TableRow key={u.id} className="border-white/5 hover:bg-white/5 transition-colors">
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
                          {u.name ? u.name[0] : '?'}
                        </div>
                        <div className="flex flex-col">
                          <span className="font-medium">{u.name}</span>
                          <span className="text-xs text-muted-foreground">{u.email}</span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1.5">
                        <Shield className={`h-3 w-3 ${u.role === 'Admin' ? 'text-primary' : 'text-muted-foreground'}`} />
                        <span className="text-sm">{u.role}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm">{u.department}</span>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20 text-[10px] uppercase font-bold tracking-wider">
                        {u.status || 'Active'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8"
                          onClick={() => handleEditClick(u)}
                        >
                          <Edit2 className="h-4 w-4 text-muted-foreground" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8 hover:text-destructive"
                          onClick={() => handleDeleteUser(u.id, u.role)}
                        >
                          <Trash2 className="h-4 w-4 text-muted-foreground" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={isEditingUser} onOpenChange={setIsEditingUser}>
        <DialogContent className="glass-panel border-white/10">
          <DialogHeader>
            <DialogTitle>Edit User Account</DialogTitle>
            <DialogDescription>
              Update information for {editingUser?.name}.
            </DialogDescription>
          </DialogHeader>
          {editingUser && (
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <label className="text-sm font-medium">Full Name</label>
                <Input 
                  placeholder="Enter full name" 
                  value={editingUser.name} 
                  onChange={(e) => setEditingUser({...editingUser, name: e.target.value})}
                  className="bg-muted/50 border-white/5" 
                />
              </div>
              <div className="grid gap-2">
                <label className="text-sm font-medium">Work Email</label>
                <Input 
                  type="email" 
                  disabled
                  value={editingUser.email}
                  className="bg-muted/20 border-white/5 opacity-70" 
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <label className="text-sm font-medium">Role</label>
                  <Select value={editingUser.role} onValueChange={(val) => setEditingUser({...editingUser, role: val})}>
                    <SelectTrigger className="bg-muted/50 border-white/5">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Admin">Admin</SelectItem>
                      <SelectItem value="Manager">Manager</SelectItem>
                      <SelectItem value="Employee">Employee</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <label className="text-sm font-medium">Department</label>
                  <Input 
                    placeholder="e.g. HR" 
                    value={editingUser.department}
                    onChange={(e) => setEditingUser({...editingUser, department: e.target.value})}
                    className="bg-muted/50 border-white/5" 
                  />
                </div>
              </div>
              <div className="grid gap-2">
                <label className="text-sm font-medium">Account Status</label>
                <Select value={editingUser.status} onValueChange={(val) => setEditingUser({...editingUser, status: val})}>
                  <SelectTrigger className="bg-muted/50 border-white/5">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Active">Active</SelectItem>
                    <SelectItem value="Suspended">Suspended</SelectItem>
                    <SelectItem value="Inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="ghost" onClick={() => setIsEditingUser(false)}>Cancel</Button>
            <Button onClick={handleUpdateUser}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
