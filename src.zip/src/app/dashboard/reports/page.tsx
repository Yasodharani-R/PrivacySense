
"use client";

import { useState } from "react";
import { 
  FileText, 
  Download, 
  Clock, 
  CheckCircle2, 
  FileBarChart, 
  Filter,
  Eye,
  ShieldCheck,
  AlertTriangle,
  Info,
  Database,
  Search,
  Loader2,
  Plus
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogTrigger,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const INITIAL_REPORTS = [
  { 
    id: 1, 
    name: 'DPDPA Quarterly Compliance Summary', 
    type: 'Executive Report', 
    lastGenerated: '2 days ago', 
    size: '2.4 MB',
    content: {
      summary: "Overall compliance standing is strong at 94.2%. Major progress made in data minimization efforts within the HR and Finance departments.",
      sections: [
        { title: "Consent Management", status: "Compliant", details: "Verified 92% of active data processing activities have explicit, documented consent strings." },
        { title: "Data Fiduciary Obligations", status: "Compliant", details: "All identified data fiduciaries have been mapped to their respective departments and data sources." }
      ],
      records: [
        { id: "REC-001", entity: "Customer Portal", attribute: "Consent Log", status: "Verified", risk: "Low" },
        { id: "REC-002", entity: "HR Management", attribute: "Employee Records", status: "Verified", risk: "Low" },
        { id: "REC-003", entity: "Finance Dept", attribute: "Tax Filings", status: "Review", risk: "Medium" }
      ]
    }
  },
  { 
    id: 2, 
    name: 'Personal Data Inventory - Full Export', 
    type: 'Technical Audit', 
    lastGenerated: '1 week ago', 
    size: '14.8 MB',
    content: {
      summary: "Comprehensive mapping of 12,482 PII elements across SQL, NoSQL, and S3 storage. 15 new unauthorized data clusters identified and remediated.",
      sections: [
        { title: "Database Discovery", status: "Verified", details: "Scanned 14 Production SQL instances. Identified 452 table columns containing PII." },
        { title: "Cloud Storage (S3)", status: "Verified", details: "2.4TB of unstructured data scanned. 85 sensitive PDF documents identified for encryption." }
      ],
      records: [
        { id: "PII-992", entity: "User_Table", attribute: "Aadhaar Number", status: "Masked", risk: "High" },
        { id: "PII-993", entity: "Health_Records", attribute: "Medical History", status: "Encrypted", risk: "Critical" },
        { id: "PII-994", entity: "Marketing_DB", attribute: "Email Address", status: "Plaintext", risk: "Medium" },
        { id: "PII-995", entity: "Transactions", attribute: "PAN Card", status: "Masked", risk: "High" },
        { id: "PII-996", entity: "Employee_Files", attribute: "Home Address", status: "Plaintext", risk: "Low" }
      ]
    }
  },
  { 
    id: 3, 
    name: 'Access Controls & Audit Log Review', 
    type: 'Security Review', 
    lastGenerated: 'Yesterday', 
    size: '1.1 MB',
    content: {
      summary: "Review of 15,000+ access events. 0% credential leakage detected. 3 administrative roles flagged for review due to inactivity.",
      sections: [
        { title: "Authentication Logs", status: "Secure", details: "Multi-factor authentication (MFA) enforcement at 100% for administrative accounts." },
        { title: "Anomaly Detection", status: "Secure", details: "Automated triggers blocked 42 unauthorized login attempts from external IP ranges." }
      ],
      records: [
        { id: "LOG-441", entity: "Admin Login", attribute: "MFA Check", status: "Pass", risk: "Low" },
        { id: "LOG-442", entity: "DB Query", attribute: "Privileged Access", status: "Authorized", risk: "Medium" },
        { id: "LOG-443", entity: "External IP", attribute: "Login Attempt", status: "Blocked", risk: "Critical" }
      ]
    }
  },
  { 
    id: 4, 
    name: 'Sensitive Data Risk Assessment', 
    type: 'Risk Analysis', 
    lastGenerated: 'Today', 
    size: '3.5 MB',
    content: {
      summary: "High-risk score (24/100) primarily driven by Finance department's temporary data cache. Proposing immediate shift to zero-trust storage.",
      sections: [
        { title: "Financial PII", status: "High Risk", details: "40% of detected financial data is stored in unencrypted staging environments." },
        { title: "Remediation Priority", status: "Urgent", details: "Apply field-level encryption to 'Table: Transactions' in Corporate DB immediately." }
      ],
      records: [
        { id: "RISK-10", entity: "Staging_DB", attribute: "Credit Card Info", status: "Exposed", risk: "Critical" },
        { id: "RISK-11", entity: "Legacy_App", attribute: "User Passwords", status: "Hashed", risk: "Medium" },
        { id: "RISK-12", entity: "S3_Backup", attribute: "Customer Invoices", status: "Public", risk: "High" }
      ]
    }
  },
];

export default function ReportsPage() {
  const { toast } = useToast();
  const [reports, setReports] = useState(INITIAL_REPORTS);
  const [selectedReport, setSelectedReport] = useState<any>(null);
  const [isViewOpen, setIsViewOpen] = useState(false);
  const [isGenerateDialogOpen, setIsGenerateDialogOpen] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [newReportSource, setNewReportSource] = useState("prod-sql");
  const [searchTerm, setSearchTerm] = useState("");
  const [recordSearch, setRecordSearch] = useState("");
  const [isDownloading, setIsDownloading] = useState<number | null>(null);

  const handleGenerateNewReport = () => {
    setIsGenerating(true);
    toast({ 
      title: "Initiating Analysis", 
      description: "AI engine is scanning repositories for DPDPA compliance..." 
    });

    // Simulate AI analysis and report compilation
    setTimeout(() => {
      const newId = Date.now();
      const sourceName = newReportSource === 'prod-sql' ? 'Production SQL' : 
                         newReportSource === 'hr-mongodb' ? 'HR MongoDB' : 
                         newReportSource === 'aws-s3-compliance' ? 'AWS S3' : 'Internal Exchange';
      
      const newReport = {
        id: newId,
        name: `Automated Compliance Audit - ${sourceName}`,
        type: 'On-Demand Scan',
        lastGenerated: 'Just now',
        size: '1.4 MB',
        content: {
          summary: `Compliance scan of ${sourceName} completed with high confidence. Data inventory mapping is 100% complete for the targeted environment.`,
          sections: [
            { title: "PII Identification", status: "Verified", details: `Scanned all active nodes in ${sourceName}. Identified 12 new data subjects and associated identifiers.` },
            { title: "Policy Compliance", status: "Compliant", details: "Current data handling aligns with DPDPA 2023 Section 4 guidelines." }
          ],
          records: [
            { id: `AUDIT-${newId.toString().slice(-4)}`, entity: sourceName, attribute: "User Profiles", status: "Audited", risk: "Low" }
          ]
        }
      };

      setReports([newReport, ...reports]);
      setIsGenerating(false);
      setIsGenerateDialogOpen(false);
      toast({ 
        title: "Report Generated", 
        description: "The new compliance report has been added to your inventory." 
      });
    }, 2500);
  };

  const handleDownload = (report: any) => {
    setIsDownloading(report.id);
    toast({ title: "Preparing Download", description: `${report.name} is being generated for export.` });
    
    setTimeout(() => {
      const reportHeader = `========================================================\n`;
      const reportTitle = `PRIVACYSENSE COMPLIANCE REPORT: ${report.name}\n`;
      const reportMeta = `Generated: ${new Date().toLocaleString()} | Type: ${report.type}\n`;
      const separator = `--------------------------------------------------------\n`;
      
      let reportBody = `${reportHeader}${reportTitle}${reportMeta}${reportHeader}\n`;
      reportBody += `EXECUTIVE SUMMARY:\n${report.content.summary}\n\n`;
      
      reportBody += `SECTIONS:\n`;
      report.content.sections.forEach((s: any) => {
        reportBody += `[${s.status}] ${s.title}: ${s.details}\n`;
      });
      
      reportBody += `\nDETAILED RECORDS:\n`;
      reportBody += `ID\t\tEntity\t\t\tAttribute\t\tStatus\t\tRisk\n`;
      report.content.records.forEach((r: any) => {
        reportBody += `${r.id}\t${r.entity.padEnd(20)}\t${r.attribute.padEnd(20)}\t${r.status}\t\t${r.risk}\n`;
      });
      
      reportBody += `\n${separator}END OF REPORT${separator}`;

      const blob = new Blob([reportBody], { type: 'text/plain' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${report.name.replace(/\s+/g, '_')}_Compliance_Report.txt`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      setIsDownloading(null);
      toast({ title: "Download Successful", description: `Report exported as .txt file.` });
    }, 1500);
  };

  const handleViewOnline = (report: any) => {
    setSelectedReport(report);
    setIsViewOpen(true);
    setRecordSearch("");
  };

  const filteredReports = reports.filter(r => 
    r.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    r.type.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredRecords = selectedReport?.content?.records?.filter((rec: any) => 
    rec.entity.toLowerCase().includes(recordSearch.toLowerCase()) ||
    rec.attribute.toLowerCase().includes(recordSearch.toLowerCase()) ||
    rec.id.toLowerCase().includes(recordSearch.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-col gap-1">
          <h1 className="text-3xl font-bold tracking-tight">Compliance Reports</h1>
          <p className="text-muted-foreground">Automated DPDPA 2023 readiness and data inventory reports.</p>
        </div>
        
        <Dialog open={isGenerateDialogOpen} onOpenChange={setIsGenerateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-2">
              <FileBarChart className="h-4 w-4" />
              Generate New Report
            </Button>
          </DialogTrigger>
          <DialogContent className="glass-panel border-white/10">
            <DialogHeader>
              <DialogTitle>Generate Compliance Report</DialogTitle>
              <DialogDescription>
                Select a data source to perform an automated DPDPA 2023 compliance audit.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <label className="text-sm font-medium">Target Repository</label>
                <Select value={newReportSource} onValueChange={setNewReportSource}>
                  <SelectTrigger className="bg-muted/30 border-white/5 h-10">
                    <SelectValue placeholder="Select Source" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="prod-sql">Production SQL Server</SelectItem>
                    <SelectItem value="hr-mongodb">HR MongoDB Cluster</SelectItem>
                    <SelectItem value="aws-s3-compliance">AWS S3 Compliance Bucket</SelectItem>
                    <SelectItem value="internal-exchange">Internal Exchange Server</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setIsGenerateDialogOpen(false)}>Cancel</Button>
              <Button onClick={handleGenerateNewReport} disabled={isGenerating}>
                {isGenerating ? (
                  <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Analyzing...</>
                ) : (
                  <><Plus className="mr-2 h-4 w-4" /> Start Audit</>
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border-white/5 glass-panel bg-primary/5">
           <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Auto-Schedule</CardTitle>
           </CardHeader>
           <CardContent>
              <p className="text-2xl font-bold">Enabled</p>
              <p className="text-xs text-muted-foreground mt-1">Monthly summary reports active</p>
           </CardContent>
        </Card>
        <Card className="border-white/5 glass-panel">
           <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Compliance Rate</CardTitle>
           </CardHeader>
           <CardContent>
              <p className="text-2xl font-bold text-emerald-500">94.2%</p>
              <p className="text-xs text-muted-foreground mt-1">+2.4% from last period</p>
           </CardContent>
        </Card>
      </div>

      <div className="flex items-center gap-4 py-2">
        <div className="relative flex-1">
          <Filter className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Filter by report name or category..." 
            className="pl-9 bg-muted/30 border-white/5 h-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredReports.map((report) => (
          <Card key={report.id} className="border-white/5 glass-panel group hover:border-primary/30 transition-all overflow-hidden">
             <div className="flex h-full">
                <div className="w-2 bg-primary group-hover:bg-primary/80" />
                <div className="flex-1 p-6">
                   <div className="flex justify-between items-start mb-4">
                      <div>
                         <Badge variant="outline" className="mb-2 text-[10px] uppercase border-white/5 bg-white/5 text-muted-foreground">{report.type}</Badge>
                         <h3 className="text-lg font-bold leading-tight">{report.name}</h3>
                      </div>
                      <div className="p-3 bg-muted/50 rounded-xl">
                         <FileText className="h-6 w-6 text-primary" />
                      </div>
                   </div>
                   <div className="flex items-center gap-6 text-sm text-muted-foreground mb-6">
                      <div className="flex items-center gap-1.5">
                         <Clock className="h-4 w-4" /> {report.lastGenerated}
                      </div>
                      <div className="flex items-center gap-1.5">
                         <Download className="h-4 w-4" /> {report.size}
                      </div>
                      <div className="flex items-center gap-1.5 text-emerald-500">
                         <CheckCircle2 className="h-4 w-4" /> Verified
                      </div>
                   </div>
                   <div className="flex gap-3">
                      <Button 
                        variant="outline" 
                        className="flex-1 border-white/5" 
                        onClick={() => handleDownload(report)}
                        disabled={isDownloading === report.id}
                      >
                        {isDownloading === report.id ? (
                          <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Generating...</>
                        ) : (
                          <><Download className="h-4 w-4 mr-2" /> Download Report</>
                        )}
                      </Button>
                      <Button 
                        variant="ghost" 
                        className="border-white/5 text-muted-foreground hover:text-primary"
                        onClick={() => handleViewOnline(report)}
                      >
                        <Eye className="h-4 w-4 mr-2" />
                        View Online
                      </Button>
                   </div>
                </div>
             </div>
          </Card>
        ))}
      </div>

      <Dialog open={isViewOpen} onOpenChange={setIsViewOpen}>
        <DialogContent className="max-w-4xl glass-panel border-white/10 max-h-[95vh] flex flex-col p-0 overflow-hidden">
          <DialogHeader className="p-6 border-b border-white/5">
            <div className="flex items-center gap-2 mb-1">
              <Badge variant="outline" className="text-[10px] uppercase bg-primary/10 text-primary border-primary/20">
                {selectedReport?.type}
              </Badge>
              <span className="text-xs text-muted-foreground">• Generated {selectedReport?.lastGenerated}</span>
            </div>
            <DialogTitle className="text-2xl font-bold tracking-tight">
              {selectedReport?.name}
            </DialogTitle>
            <DialogDescription>
              Internal compliance record summary for DPDPA 2023 auditing.
            </DialogDescription>
          </DialogHeader>
          
          <ScrollArea className="flex-1 px-6 py-4">
            <div className="space-y-8 pb-6">
              <section className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-widest text-primary flex items-center gap-2">
                  <Info className="h-3 w-3" /> Executive Summary
                </h4>
                <div className="p-4 rounded-xl bg-white/5 border border-white/5 text-sm leading-relaxed italic text-muted-foreground">
                  "{selectedReport?.content?.summary}"
                </div>
              </section>

              <section className="space-y-4">
                <h4 className="text-xs font-bold uppercase tracking-widest text-primary flex items-center gap-2">
                  <ShieldCheck className="h-3 w-3" /> Report Sections & Status
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {selectedReport?.content?.sections.map((section: any, idx: number) => (
                    <div key={idx} className="p-4 rounded-xl bg-muted/30 border border-white/5 space-y-2">
                      <div className="flex items-center justify-between">
                        <h5 className="font-bold text-sm">{section.title}</h5>
                        <Badge 
                          variant="outline" 
                          className={`text-[10px] uppercase px-2 h-5 font-bold ${
                            section.status === 'High Risk' || section.status === 'At Risk' ? 'text-destructive border-destructive/20 bg-destructive/10' :
                            section.status === 'Review Needed' ? 'text-amber-500 border-amber-500/20 bg-amber-500/10' :
                            'text-emerald-500 border-emerald-500/20 bg-emerald-500/10'
                          }`}
                        >
                          {section.status}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground leading-relaxed">{section.details}</p>
                    </div>
                  ))}
                </div>
              </section>

              <section className="space-y-4">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <h4 className="text-xs font-bold uppercase tracking-widest text-primary flex items-center gap-2">
                    <Database className="h-3 w-3" /> Detailed Record Findings
                  </h4>
                  <div className="relative w-full md:w-64">
                    <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                    <Input 
                      placeholder="Search records..." 
                      className="h-8 pl-8 text-xs bg-muted/20 border-white/5"
                      value={recordSearch}
                      onChange={(e) => setRecordSearch(e.target.value)}
                    />
                  </div>
                </div>
                
                <div className="border border-white/5 rounded-xl overflow-hidden bg-white/5">
                  <Table>
                    <TableHeader className="bg-muted/30">
                      <TableRow className="border-white/5 hover:bg-transparent">
                        <TableHead className="text-[10px] font-bold uppercase tracking-tight h-10">Record ID</TableHead>
                        <TableHead className="text-[10px] font-bold uppercase tracking-tight h-10">Entity / Source</TableHead>
                        <TableHead className="text-[10px] font-bold uppercase tracking-tight h-10">Attribute Type</TableHead>
                        <TableHead className="text-[10px] font-bold uppercase tracking-tight h-10">Status</TableHead>
                        <TableHead className="text-[10px] font-bold uppercase tracking-tight h-10 text-right">Risk</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredRecords?.map((record: any) => (
                        <TableRow key={record.id} className="border-white/5 hover:bg-white/5">
                          <TableCell className="text-xs font-mono py-3">{record.id}</TableCell>
                          <TableCell className="text-xs font-medium py-3">{record.entity}</TableCell>
                          <TableCell className="text-xs py-3">{record.attribute}</TableCell>
                          <TableCell className="py-3">
                            <Badge variant="outline" className="text-[9px] h-4 border-white/5 bg-white/5">
                              {record.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right py-3">
                            <span className={`text-[10px] font-bold ${
                              record.risk === 'Critical' ? 'text-destructive' :
                              record.risk === 'High' ? 'text-amber-500' :
                              record.risk === 'Medium' ? 'text-primary' : 'text-emerald-500'
                            }`}>
                              {record.risk}
                            </span>
                          </TableCell>
                        </TableRow>
                      ))}
                      {filteredRecords?.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={5} className="h-24 text-center text-xs text-muted-foreground">
                            No records matching search criteria.
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </section>

              <Separator className="bg-white/5" />

              <section className="p-4 rounded-xl border border-destructive/20 bg-destructive/5 flex gap-4 items-start">
                <AlertTriangle className="h-5 w-5 text-destructive shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="text-sm font-bold text-destructive">Compliance Notice</p>
                  <p className="text-[11px] text-muted-foreground leading-relaxed">
                    This preview contains sensitive organizational security data. Redistribution outside of authorized compliance channels is strictly prohibited under internal policy PS-2024-SEC. All access attempts to this online view are logged.
                  </p>
                </div>
              </section>
            </div>
          </ScrollArea>

          <DialogFooter className="p-6 border-t border-white/5 bg-background/50">
            <Button variant="outline" className="border-white/5 h-10" onClick={() => setIsViewOpen(false)}>
              Close Preview
            </Button>
            <Button 
              className="gap-2 h-10" 
              onClick={() => handleDownload(selectedReport)}
              disabled={isDownloading === selectedReport?.id}
            >
              {isDownloading === selectedReport?.id ? (
                <><Loader2 className="h-4 w-4 animate-spin" /> Preparing...</>
              ) : (
                <><Download className="h-4 w-4" /> Download Full Report</>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
