
"use client";

import { useState } from "react";
import { 
  Search, 
  Shield, 
  Database, 
  Loader2, 
  CheckCircle2, 
  FileSearch,
  Scan,
  Download,
  Fingerprint,
  Info,
  AlertCircle,
  Clock,
  RefreshCw,
  RotateCcw
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { analyzeCompliance, ComplianceAnalysisOutput } from "@/ai/flows/compliance-analysis-flow";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

const MOCK_DATA_BY_SOURCE: Record<string, string[]> = {
  "prod-sql": [
    "Table: Users, Row: 104, Data: { name: 'Amit Sharma', email: 'amit.s@fintech-solutions.co.in', phone: '+91 98765 43210' }",
    "Table: Transactions, Row: 882, Data: { account_no: '4592 1002 4432', type: 'Credit', amount: 45000.00, pan: 'ABCDE1234F' }",
    "Table: Logs, Row: 1552, Data: { ip: '192.168.1.45', user: 'j_doe_admin', action: 'EXPORT_CSV' }"
  ],
  "hr-mongodb": [
    "Collection: Employees, ID: 6502a1b, Data: { full_name: 'Ananya Iyer', personal_email: 'ananya.iyer.private@gmail.com', mobile: '+91 90000 11111' }",
    "Collection: Payroll, ID: 6502c4d, Data: { emp_id: 'PS-901', pan_number: 'BKPIY9012Z', salary_bank_account: '123456789012', aadhaar: '9012 3456 7890' }",
    "Collection: Medical_Benefits, ID: 6502e9f, Data: { name: 'Ananya Iyer', condition: 'Chronic Migraine History', primary_physician: 'Dr. Mehta' }",
    "Collection: Performance, ID: 6502f10, Data: { emp_id: 'PS-901', rating: 'Exceeds Expectations', review_date: '2024-01-15' }"
  ],
  "aws-s3-compliance": [
    "File: scans/onboarding/verma_aadhaar.pdf, Content: 'Government of India... Aadhaar No: 4433 2211 0099... Name: Priya Verma... DOB: 12/05/1990...'",
    "File: finance/reports/Q3_Audit.xlsx, Sheet: Personnel, Row: 42, Data: { name: 'Vikram Singh', pan: 'BKPIY9012Z', salary: 1200000 }",
    "File: legal/notices/termination_dhillon.pdf, Content: 'Notice to Mr. Ravinder Dhillon... PAN: RD776655A... Address: Sector 17, Chandigarh...'",
    "File: hr/backups/tax_forms_2023.zip/form_16_amit.pdf, Content: 'Form 16... Employer: PrivacySense... Employee: Amit Sharma... PAN: AS998877K...'"
  ],
  "internal-exchange": [
    "Mail: id_9921, From: recruitment@privacysense.com, Subject: Candidate Application - Rahul Khanna, Body: 'Dear Hiring Manager, please find attached the resume for Rahul Khanna. Contact: +91 99887 76655, pan: RHVPA1122M...'",
    "Mail: id: 9922, From: it-support@privacysense.com, Subject: Access Request, Body: 'Please grant DB access to user root_admin...'",
    "Mail: id_10045, From: ananya.i@privacysense.com, Subject: RE: Medical Reimbursement, Body: 'Attached medical bill for surgery at Apollo Hospital. Patient: Ananya Iyer, ID: PS-901, Treatment: Emergency Appendectomy...'",
    "Mail: id_10050, From: system@privacysense.com, Subject: Password Reset - Amit S, Body: 'Your temporary password is: Temp123! For user: amit.s@fintech-solutions.co.in...'",
    "Mail: id_10060, From: payroll@privacysense.com, Subject: Salary Slip May 2024, Body: 'Employee Name: Ananya Iyer, Account: 9012334455, Bank: HDFC, PAN: BKPIY9012Z...'"
  ]
};

export default function DiscoveryPage() {
  const { toast } = useToast();
  const [selectedSource, setSelectedSource] = useState("prod-sql");
  const [isScanning, setIsScanning] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [scanError, setScanError] = useState<string | null>(null);
  const [isQuotaError, setIsQuotaError] = useState(false);
  const [results, setResults] = useState<ComplianceAnalysisOutput | null>(null);

  const handleStartScan = async () => {
    setIsScanning(true);
    setScanProgress(0);
    setScanError(null);
    setIsQuotaError(false);
    setResults(null);

    const progressInterval = setInterval(() => {
      setScanProgress(prev => {
        if (prev >= 95) return prev; 
        return prev + 1;
      });
    }, 150);

    try {
      const records = MOCK_DATA_BY_SOURCE[selectedSource] || MOCK_DATA_BY_SOURCE["prod-sql"];
      const contentToScan = records.join("\n");
      
      // Perform consolidated analysis in ONE request to save quota
      const analysisRes = await analyzeCompliance({ dataContent: contentToScan });

      setResults(analysisRes);
      setScanProgress(100);
      toast({ 
        title: "Scan Complete", 
        description: `Identified ${analysisRes.detectedData.length} PII elements and classified as ${analysisRes.classification}.` 
      });
    } catch (error: any) {
      console.error("Discovery Engine Error:", error);
      
      const errorMessage = error?.message || (typeof error === 'string' ? error : "An unknown processing error occurred.");
      
      const isQuota = 
        errorMessage.includes("429") || 
        errorMessage.includes("RESOURCE_EXHAUSTED") || 
        errorMessage.includes("quota") ||
        errorMessage.includes("limit") ||
        errorMessage.includes("Too Many Requests");

      setIsQuotaError(isQuota);
      
      if (isQuota) {
        setScanError("AI Service Rate Limit (20 RPM) exceeded. Consolidated processing used 1 request, but the limit was already reached.");
      } else {
        setScanError(errorMessage);
      }
      
      toast({ 
        title: isQuota ? "Quota Reached" : "Scan Error", 
        description: isQuota ? "Please wait a moment before retrying." : "The discovery engine encountered an error.", 
        variant: "destructive" 
      });
    } finally {
      clearInterval(progressInterval);
      setIsScanning(false);
    }
  };

  const handleReset = () => {
    setResults(null);
    setScanError(null);
    setIsQuotaError(false);
    setScanProgress(0);
    toast({ title: "Engine Reset", description: "All scan states have been cleared." });
  };

  const handleExportReport = () => {
    if (!results) return;

    setIsExporting(true);
    toast({ 
      title: "Preparing Export", 
      description: "Compiling findings into DPDPA audit format..." 
    });

    setTimeout(() => {
      const timestamp = new Date().toLocaleString();
      const separator = "========================================================\n";
      const subSeparator = "--------------------------------------------------------\n";
      
      let reportContent = `${separator}`;
      reportContent += `PRIVACYSENSE COMPLIANCE AUDIT REPORT\n`;
      reportContent += `Generated: ${timestamp}\n`;
      reportContent += `Data Source: ${selectedSource}\n`;
      reportContent += `${separator}\n`;

      reportContent += `AI CLASSIFICATION: ${results.classification.toUpperCase()}\n`;
      reportContent += `REASONING: ${results.reasoning}\n\n`;

      reportContent += `IDENTIFIED PII ELEMENTS (${results.detectedData.length}):\n`;
      reportContent += `TYPE\t\t\tVALUE\n`;
      reportContent += `${subSeparator}`;

      results.detectedData.forEach(item => {
        reportContent += `${item.type.padEnd(20)}\t${item.value}\n`;
      });

      reportContent += `\n${separator}`;
      reportContent += `END OF COMPLIANCE RECORD\n`;
      reportContent += `${separator}`;

      const blob = new Blob([reportContent], { type: 'text/plain' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `Compliance_Report_${selectedSource}_${Date.now()}.txt`;
      document.body.appendChild(link);
      link.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(link);

      setIsExporting(false);
      toast({ 
        title: "Export Ready", 
        description: "Your compliance report has been downloaded." 
      });
    }, 1000);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-col gap-1">
          <h1 className="text-3xl font-bold tracking-tight">Discovery Engine</h1>
          <p className="text-muted-foreground">AI-powered personal data identification and classification.</p>
        </div>
        <div className="flex gap-3">
          <Button 
            variant="outline"
            onClick={handleReset}
            className="border-white/10 bg-white/5"
            disabled={isScanning}
          >
            <RotateCcw className="mr-2 h-4 w-4" />
            Reset Engine
          </Button>
          <Button 
            onClick={handleStartScan} 
            disabled={isScanning} 
            className="bg-primary hover:bg-primary/90 min-w-[200px] h-11"
          >
            {isScanning ? (
              <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Analyzing Content...</>
            ) : (
              <><Search className="mr-2 h-4 w-4" /> Start Compliance Scan</>
            )}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-1 border-white/5 glass-panel h-fit">
          <CardHeader>
            <CardTitle className="text-lg">Scan Settings</CardTitle>
            <CardDescription>Configure target repository</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-3">
              <label className="text-xs font-bold uppercase text-muted-foreground tracking-wider">Repository Source</label>
              <Select value={selectedSource} onValueChange={setSelectedSource}>
                <SelectTrigger className="bg-muted/30 border-white/10 h-12">
                  <SelectValue placeholder="Select Source" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="prod-sql">Production SQL Server</SelectItem>
                  <SelectItem value="hr-mongodb">HR MongoDB Cluster</SelectItem>
                  <SelectItem value="aws-s3-compliance">AWS S3 Compliance Bucket</SelectItem>
                  <SelectItem value="internal-exchange">Internal Exchange Server</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-4">
              <label className="text-xs font-bold uppercase text-muted-foreground tracking-wider">Quota Optimization</label>
              <div className="p-4 rounded-xl bg-primary/5 border border-primary/10">
                <div className="flex items-start gap-3">
                  <Info className="h-4 w-4 text-primary mt-0.5" />
                  <p className="text-[11px] text-muted-foreground leading-relaxed">
                    <strong>Consolidated Analysis Active:</strong> Discovery and Classification are now combined into a single request to double your scanning capacity on the free tier.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2 border-white/5 glass-panel min-h-[500px] flex flex-col overflow-hidden">
          <CardContent className="flex-1 p-0 flex flex-col items-center justify-center">
            {scanError ? (
              <div className="p-8 w-full max-w-lg animate-in fade-in slide-in-from-bottom-4">
                <Alert variant="destructive" className="bg-destructive/10 border-destructive/20 py-8">
                  {isQuotaError ? <Clock className="h-6 w-6" /> : <AlertCircle className="h-6 w-6" />}
                  <AlertTitle className="font-bold text-xl mb-3">
                    {isQuotaError ? "AI Service Rate Limit" : "Scan Interrupted"}
                  </AlertTitle>
                  <AlertDescription className="text-sm leading-relaxed space-y-4">
                    <p className="text-foreground/80">{scanError}</p>
                    {isQuotaError && (
                      <div className="space-y-4">
                        <p className="text-xs opacity-80">
                          The Gemini 2.5 Flash engine has a limit of 20 requests per minute. Your scan was paused to prevent service disruption.
                        </p>
                        <div className="p-4 rounded bg-black/40 font-mono text-[11px] border border-white/10">
                          <p className="text-primary font-bold mb-1 uppercase">Recommended Action:</p>
                          <p className="opacity-70">Please wait roughly 30-60 seconds before initiating another scan to reset your request window.</p>
                        </div>
                      </div>
                    )}
                    <Button 
                      variant="outline" 
                      className="mt-6 border-white/10 bg-white/5 w-full gap-2"
                      onClick={handleStartScan}
                    >
                      <RefreshCw className="h-4 w-4" />
                      Try Scanning Again
                    </Button>
                  </AlertDescription>
                </Alert>
              </div>
            ) : !isScanning && !results ? (
              <div className="text-center space-y-4 max-w-sm px-6">
                <div className="mx-auto w-20 h-20 bg-muted/50 rounded-full flex items-center justify-center border border-white/5 shadow-inner">
                  <FileSearch className="h-10 w-10 text-muted-foreground/30" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl font-bold tracking-tight">Engine Ready</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Select a data repository and initiate a scan. The engine now uses consolidated analysis to optimize your API usage.
                  </p>
                </div>
              </div>
            ) : isScanning ? (
              <div className="w-full max-w-md px-10 space-y-8">
                <div className="space-y-4 text-center">
                  <div className="relative mx-auto w-28 h-28">
                    <Scan className="absolute inset-0 m-auto h-14 w-14 text-primary animate-pulse" />
                    <div className="absolute inset-0 border-[6px] border-primary/10 border-t-primary rounded-full animate-spin" />
                  </div>
                  <div className="space-y-1">
                    <h3 className="font-bold text-2xl tracking-tight">Analyzing Records</h3>
                    <p className="text-sm text-muted-foreground italic">Performing consolidated DPDPA check on {selectedSource}...</p>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between text-[10px] font-bold font-mono tracking-[0.2em] text-primary/70">
                    <span>AI PROCESSING</span>
                    <span>{scanProgress}%</span>
                  </div>
                  <Progress value={scanProgress} className="h-2 bg-white/5" />
                </div>
              </div>
            ) : (
              <div className="w-full h-full flex flex-col p-6 space-y-6 animate-in fade-in zoom-in duration-500">
                <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-white/5 pb-6 gap-4">
                  <div>
                    <h3 className="text-2xl font-bold tracking-tight">Scan Summary: {selectedSource}</h3>
                    <p className="text-xs text-muted-foreground font-mono mt-1 opacity-50">AUDIT_REF: {Math.random().toString(36).substr(2, 9).toUpperCase()}</p>
                  </div>
                  <Badge className="bg-primary/10 text-primary border-primary/20 text-xs py-1 px-4 h-fit">
                    {results?.classification}
                  </Badge>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-6">
                    <div className="space-y-3">
                      <h4 className="text-xs font-bold uppercase text-muted-foreground tracking-widest flex items-center gap-2">
                        <Shield className="h-3 w-3" /> AI Risk Reasoning
                      </h4>
                      <div className="p-5 rounded-2xl bg-white/5 border border-white/5 shadow-sm">
                        <p className="text-sm font-medium leading-relaxed italic text-foreground/80">
                          "{results?.reasoning}"
                        </p>
                        <div className="mt-4 pt-4 border-t border-white/5 flex items-center gap-2 text-[11px] text-emerald-500 font-bold uppercase tracking-wider">
                          <CheckCircle2 className="h-3.5 w-3.5" /> Policy Check Verified
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="text-xs font-bold uppercase text-muted-foreground tracking-widest flex items-center gap-2">
                      <Fingerprint className="h-3 w-3" /> Discovered PII ({results?.detectedData.length})
                    </h4>
                    <div className="max-h-[320px] overflow-y-auto pr-3 space-y-2 custom-scrollbar">
                      {results?.detectedData.map((data, idx) => (
                        <div key={idx} className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/5 hover:bg-white/10 transition-all group">
                          <div className="min-w-0">
                            <p className="text-[10px] font-bold text-primary uppercase leading-none mb-1.5 tracking-wide">{data.type}</p>
                            <p className="text-sm truncate font-mono text-muted-foreground group-hover:text-foreground transition-colors">{data.value}</p>
                          </div>
                          <Badge variant="outline" className="text-[9px] h-5 border-emerald-500/20 text-emerald-500 bg-emerald-500/5">AUDITED</Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
          {(results || scanError) && (
            <CardFooter className="border-t border-white/5 p-6 flex justify-end gap-4 bg-muted/10">
              <Button 
                variant="ghost" 
                className="h-10 text-muted-foreground hover:text-foreground" 
                onClick={handleReset}
                disabled={isExporting}
              >
                Clear Results
              </Button>
              {results && (
                <Button 
                  className="h-10 gap-2 shadow-lg px-6" 
                  onClick={handleExportReport}
                  disabled={isExporting}
                >
                  {isExporting ? (
                    <><Loader2 className="h-4 w-4 animate-spin" /> Finalizing...</>
                  ) : (
                    <><Download className="h-4 w-4" /> Export Audit Report</>
                  )}
                </Button>
              )}
            </CardFooter>
          )}
        </Card>
      </div>
    </div>
  );
}
