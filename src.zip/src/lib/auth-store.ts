"use client";

import { create } from 'zustand';

export type UserRole = 'Admin' | 'Manager' | 'Employee';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  department?: string;
}

interface AuthState {
  user: User | null;
  login: (email: string, role: UserRole) => void;
  logout: () => void;
}

// Simple browser-based state for the prototype
export const useAuthStore = (typeof window !== 'undefined') ? 
  create<AuthState>((set) => ({
    user: JSON.parse(localStorage.getItem('ps_user') || 'null'),
    login: (email, role) => {
      const newUser = { 
        id: Math.random().toString(36).substr(2, 9), 
        email, 
        role, 
        name: email.split('@')[0],
        department: role === 'Manager' ? 'Compliance' : 'Operations'
      };
      set({ user: newUser });
      localStorage.setItem('ps_user', JSON.stringify(newUser));
    },
    logout: () => {
      set({ user: null });
      localStorage.removeItem('ps_user');
    },
  })) : 
  // SSR fallback
  (() => {
    return {
      user: null,
      login: () => {},
      logout: () => {},
    } as AuthState;
  }) as any;
