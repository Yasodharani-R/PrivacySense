'use server';
/**
 * @fileOverview A consolidated AI flow for both discovering PII and classifying data sensitivity in one request.
 * This optimization halves API quota usage and improves performance.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ComplianceAnalysisInputSchema = z.object({
  dataContent: z.string().describe('The text content to be analyzed for personal data and classified for sensitivity.'),
});

export type ComplianceAnalysisInput = z.infer<typeof ComplianceAnalysisInputSchema>;

const ComplianceAnalysisOutputSchema = z.object({
  detectedData: z.array(z.object({
    type: z.enum(['Name', 'Email', 'Phone Number', 'Aadhaar Number', 'PAN Number', 'Bank Account Number', 'Health Information', 'Other']),
    value: z.string().describe('The detected value.'),
  })).describe('List of discovered PII elements.'),
  classification: z.enum(['Highly Sensitive Data', 'Personal Data', 'General Data']).describe('The DPDPA classification.'),
  reasoning: z.string().describe('Explanation for the classification based on detected identifiers.'),
});

export type ComplianceAnalysisOutput = z.infer<typeof ComplianceAnalysisOutputSchema>;

export async function analyzeCompliance(input: ComplianceAnalysisInput): Promise<ComplianceAnalysisOutput> {
  return complianceAnalysisFlow(input);
}

const complianceAnalysisPrompt = ai.definePrompt({
  name: 'complianceAnalysisPrompt',
  input: {schema: ComplianceAnalysisInputSchema},
  output: {schema: ComplianceAnalysisOutputSchema},
  prompt: `You are an expert data privacy officer and compliance auditor specializing in DPDPA 2023.
Your task is to perform a comprehensive analysis of the provided text content.

Perform the following two tasks in a single analysis:

1. **Personal Data Discovery**: Identify all personal identifiers including Names, Emails, Phone Numbers, Aadhaar Numbers, PAN Numbers, Bank Account Numbers, and Health Information.
2. **Data Classification**: Classify the entire text block into one of these categories:
   - 'Highly Sensitive Data': Financial info, health info, biometric data, Aadhaar, or PAN.
   - 'Personal Data': Names, emails, phone numbers, or residential addresses.
   - 'General Data': Public information or non-identifiable business data.

Provide a clear reasoning for your classification based on the specific identifiers you discovered.

Analyze the following text:
"""{{{dataContent}}}"""`,
});

const complianceAnalysisFlow = ai.defineFlow(
  {
    name: 'complianceAnalysisFlow',
    inputSchema: ComplianceAnalysisInputSchema,
    outputSchema: ComplianceAnalysisOutputSchema,
  },
  async input => {
    const {output} = await complianceAnalysisPrompt(input);
    if (!output) {
      throw new Error('Compliance analysis failed: No output returned from AI engine.');
    }
    return output;
  }
);
