'use server';
/**
 * @fileOverview A Genkit flow for discovering and classifying personal data within provided text content.
 *
 * - discoverPersonalData - A function that initiates the personal data discovery process.
 * - PersonalDataDiscoveryInput - The input type for the discoverPersonalData function.
 * - PersonalDataDiscoveryOutput - The return type for the discoverPersonalData function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const PersonalDataDiscoveryInputSchema = z
  .object({
    dataContent: z
      .string()
      .describe('The text content to be scanned for personal data.'),
  })
  .describe('Input for the personal data discovery flow.');

export type PersonalDataDiscoveryInput = z.infer<
  typeof PersonalDataDiscoveryInputSchema
>;

const PersonalDataDiscoveryOutputSchema = z
  .object({
    detectedData: z
      .array(
        z.object({
          type: z
            .enum([
              'Name',
              'Email',
              'Phone Number',
              'Aadhaar Number',
              'PAN Number',
              'Bank Account Number',
              'Health Information',
              'Other'
            ])
            .describe('The type of personal data detected.'),
          value: z.string().describe('The detected personal data value.'),
        })
      )
      .describe('An array of detected personal data items.'),
  })
  .describe('Output of the personal data discovery flow.');

export type PersonalDataDiscoveryOutput = z.infer<
  typeof PersonalDataDiscoveryOutputSchema
>;

export async function discoverPersonalData(
  input: PersonalDataDiscoveryInput
): Promise<PersonalDataDiscoveryOutput> {
  return personalDataDiscoveryFlow(input);
}

const personalDataDiscoveryPrompt = ai.definePrompt({
  name: 'personalDataDiscoveryPrompt',
  input: {schema: PersonalDataDiscoveryInputSchema},
  output: {schema: PersonalDataDiscoveryOutputSchema},
  prompt: `You are an expert personal data detection and classification system.
Your task is to analyze the provided text content and identify all instances of personal identifiers.
For each identified item, categorize it into one of the following types: 'Name', 'Email', 'Phone Number', 'Aadhaar Number', 'PAN Number', 'Bank Account Number', 'Health Information', or 'Other'.
Extract the exact value of the detected data.

Personal identifiers to detect:
- **Names**: Common first names, last names, and full names.
- **Phone numbers**: Various formats (e.g., +1 (123) 456-7890, 123-456-7890, 1234567890).
- **Email addresses**: Standard email formats (e.g., user@example.com).
- **Aadhaar numbers**: Indian national ID, typically a 12-digit number, sometimes formatted with spaces (e.g., 1234 5678 9012).
- **PAN numbers**: Indian Permanent Account Number, a 10-character alphanumeric identifier (e.g., ABCDE1234F).
- **Bank account numbers**: Numeric sequences that resemble account numbers, often paired with bank names or related terms.
- **Health information**: Any explicit mentions of medical conditions, treatments, or health status.

If no personal data is found, return an empty array for 'detectedData'.

Analyze the following text:
{{{dataContent}}}`,
});

const personalDataDiscoveryFlow = ai.defineFlow(
  {
    name: 'personalDataDiscoveryFlow',
    inputSchema: PersonalDataDiscoveryInputSchema,
    outputSchema: PersonalDataDiscoveryOutputSchema,
  },
  async input => {
    const {output} = await personalDataDiscoveryPrompt(input);
    if (!output) {
      throw new Error('Failed to detect personal data.');
    }
    return output;
  }
);
