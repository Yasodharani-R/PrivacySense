'use server';
/**
 * @fileOverview An AI agent for classifying personal data based on DPDPA guidelines.
 *
 * - intelligentDataClassification - A function that handles the personal data classification process.
 * - IntelligentDataClassificationInput - The input type for the intelligentDataClassification function.
 * - IntelligentDataClassificationOutput - The return type for the intelligentDataClassification function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const IntelligentDataClassificationInputSchema = z.object({
  textData: z
    .string()
    .describe('The raw text content to be classified for personal data.'),
});
export type IntelligentDataClassificationInput = z.infer<
  typeof IntelligentDataClassificationInputSchema
>;

const IntelligentDataClassificationOutputSchema = z.object({
  classification: z
    .enum(['Highly Sensitive Data', 'Personal Data', 'General Data'])
    .describe(
      "The classification of the text data: 'Highly Sensitive Data', 'Personal Data', or 'General Data'."
    ),
  reasoning: z
    .string()
    .describe('A brief explanation for the chosen classification.'),
});
export type IntelligentDataClassificationOutput = z.infer<
  typeof IntelligentDataClassificationOutputSchema
>;

export async function intelligentDataClassification(
  input: IntelligentDataClassificationInput
): Promise<IntelligentDataClassificationOutput> {
  return intelligentDataClassificationFlow(input);
}

const intelligentDataClassificationPrompt = ai.definePrompt({
  name: 'intelligentDataClassificationPrompt',
  input: {schema: IntelligentDataClassificationInputSchema},
  output: {schema: IntelligentDataClassificationOutputSchema},
  prompt: `You are an expert in data privacy and compliance, specifically with the Digital Personal Data Protection Act, 2023 (DPDPA).
Your task is to analyze the provided text content and classify it into one of the following categories:
- 'Highly Sensitive Data': Data that, if compromised, could lead to significant harm or discrimination. This includes financial details (e.g., bank account numbers, credit card numbers), health information, biometric data, Aadhaar numbers, PAN numbers.
- 'Personal Data': Any data relating to an identified or identifiable individual. This includes names, email addresses, phone numbers, addresses, unique identifiers (excluding highly sensitive ones).
- 'General Data': Data that does not fall into 'Highly Sensitive Data' or 'Personal Data' categories. This includes public information, general business data, or anonymized/aggregated data.

Provide the classification and a clear reasoning for your choice.

Text Content: """{{{textData}}}"""`,
});

const intelligentDataClassificationFlow = ai.defineFlow(
  {
    name: 'intelligentDataClassificationFlow',
    inputSchema: IntelligentDataClassificationInputSchema,
    outputSchema: IntelligentDataClassificationOutputSchema,
  },
  async input => {
    const {output} = await intelligentDataClassificationPrompt(input);
    if (!output) {
      throw new Error('Failed to classify data: No output from prompt.');
    }
    return output;
  }
);
