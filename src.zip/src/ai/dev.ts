import { config } from 'dotenv';
config();

import '@/ai/flows/intelligent-data-classification.ts';
import '@/ai/flows/personal-data-discovery.ts';
import '@/ai/flows/compliance-analysis-flow.ts';
