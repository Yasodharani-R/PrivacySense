export const firebaseConfig = {
  "projectId": "studio-1898298856-30158",
  "appId": "1:921169541756:web:cd6f82beab933f2ee6e7f9",
  "apiKey": "AIzaSyBR-Xg8Qbtf2RjqLLB11chrlb-1qa5DxdU",
  "authDomain": "studio-1898298856-30158.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "921169541756"
};
